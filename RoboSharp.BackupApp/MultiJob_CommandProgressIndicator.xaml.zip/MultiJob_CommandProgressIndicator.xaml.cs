﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace RoboSharp.BackupApp
{
    /// <summary>
    /// Interaction logic for MultiJob_CommandProgressIndicator.xaml
    /// </summary>
    public partial class MultiJob_CommandProgressIndicator : Expander
    {
        public MultiJob_CommandProgressIndicator()
        {
            InitializeComponent();
        }

        public MultiJob_CommandProgressIndicator(RoboCommand cmd)
        {
            InitializeComponent();
            BindToCommand(cmd);
        }


        public RoboCommand Command { get; private set; }

        public string JobName { 
            get => jobName;
            set 
            { 
                if (value != jobName)
                {
                    jobName = String.IsNullOrWhiteSpace(value) ? "" : value;
                    Dispatcher.Invoke(() => this.Header = $"Progress{(jobName == "" ? "" : $" - {jobName}")}");
                }
            }
             
        }   
        private string jobName;

        private List<string> Dirs;
        private List<string> Files;
        private List<string> Dirs2;
        private List<string> Files2;
        private List<string> OrderLog_1;
        private List<string> OrderLog_2;


        public void BindToCommand(RoboCommand cmd)
        {
            Command = cmd;
            if (cmd.IProgressEstimator != null)
            {
                BindToProgressEstimator(cmd.IProgressEstimator);
            }
            else
            {
                cmd.OnProgressEstimatorCreated += OnProgressEstimatorCreated;
            }
            SetupListObjs();
            cmd.OnCopyProgressChanged += OnCopyProgressChanged;
            cmd.OnFileProcessed += OnFileProcessed;
            cmd.OnCommandCompleted += OnCommandCompleted;
            JobName = cmd.Name;
        }

        private void SetupListObjs()
        {
            Dirs = new List<string> { "Dirs Reported by OnFileProcessed", "---------------------" };
            Files = new List<string> { "Files Reported by OnFileProcessed", "---------------------" };
            Dirs2 = new List<string> { "Unique Dirs Reported by CopyProgressChanged", "---------------------" };
            Files2 = new List<string> { "Unique Files Reported by CopyProgressChanged", "---------------------" };
            OrderLog_1 = new List<string> { "Files and Dirs In Order Reported by OnFileProcessed", "---------------------" };
            OrderLog_2 = new List<string> { "Files and Dirs In Order Reported by CopyProgressChanged", "---------------------" };
        }

        #region < Buttons >

        public void PauseResumeButton_Click(object sender, RoutedEventArgs e)
        {
            if (Command != null)
            {
                if (!Command.IsPaused)
                {
                    Command.Pause();
                    PauseResumeButton.Content = "Resume";
                }
                else
                {
                    Command.Resume();
                    PauseResumeButton.Content = "Pause";
                }
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            if (Command != null)
            {
                Command.Stop();
            }
        }

        #endregion

        #region < Progress Estimator >

        /// <summary> Bind the ProgressEstimator to the text controls on the PROGRESS tab </summary>
        private void OnProgressEstimatorCreated(object sender, EventArgObjects.ProgressEstimatorCreatedEventArgs e) => BindToProgressEstimator(e.ResultsEstimate);

        private void BindToProgressEstimator(RoboSharp.Interfaces.IProgressEstimator e)
        {
            Dispatcher.Invoke(() =>
            {
                ProgressEstimator_Files.Text = "Files";
                ProgressEstimator_Directories.Text = "Directories";
                ProgressEstimator_Bytes.Text = "Bytes";
            });
            e.BytesStatistic.PropertyChanged += ByteStats_PropertyChanged;
            e.DirectoriesStatistic.PropertyChanged += DirStats_PropertyChanged;
            e.FilesStatistic.PropertyChanged += FileStats_PropertyChanged;
        }

        private void FileStats_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            ProgressEstimator_Files.Dispatcher.Invoke(() => ProgressEstimator_Files.Text = ((RoboSharp.Results.Statistic)sender).ToString(true, true, "\n", true));
        }

        private void DirStats_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            ProgressEstimator_Directories.Dispatcher.Invoke(() => ProgressEstimator_Directories.Text = ((RoboSharp.Results.Statistic)sender).ToString(true, true, "\n", true));
        }

        private void ByteStats_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            ProgressEstimator_Bytes.Dispatcher.Invoke(() => ProgressEstimator_Bytes.Text = ((RoboSharp.Results.Statistic)sender).ToString(true, true, "\n", true));

        }

        #endregion

        #region < On*Processed >

        private string DirString(ProcessedFileInfo pf) => pf.FileClass + "(" + pf.Size + ") - " + pf.Name;
        private string FileString(ProcessedFileInfo pf) => pf.FileClass + "(" + pf.Size + ") - " + pf.Name;

        void OnCopyProgressChanged(object sender, CopyProgressEventArgs e) 
        {
            Dispatcher.BeginInvoke((Action)(() =>
            {
                ProgressBar.Value = e.CurrentFileProgress;
                FileProgressPercent.Text = string.Format("{0}%", e.CurrentFileProgress);
            }));
            if (e.CurrentDirectory != null)
                if (Dirs2.Count == 0 || e.CurrentDirectory.Name != Dirs2.Last())
                {
                    Dirs2.Add(DirString(e.CurrentDirectory));
                    OrderLog_2.Add(Environment.NewLine + DirString(e.CurrentDirectory));
                }
            if (e.CurrentFile != null)
                if (Files2.Count == 0 || e.CurrentFile.Name != Files2.Last())
                {
                    Files2.Add(FileString(e.CurrentFile));
                    OrderLog_2.Add(FileString(e.CurrentFile));
                }
        }

        void OnFileProcessed(object sender, FileProcessedEventArgs e)
        {
            Dispatcher.BeginInvoke((Action)(() =>
            {
                CurrentOperation.Text = e.ProcessedFile.FileClass;
                CurrentFile.Text = e.ProcessedFile.Name;
                CurrentSize.Text = e.ProcessedFile.Size.ToString();
            }));

            if (e.ProcessedFile.FileClassType == FileClassType.NewDir)
            {
                Dirs.Add(DirString(e.ProcessedFile));
                OrderLog_1.Add(Environment.NewLine + DirString(e.ProcessedFile));
            }
            else if (e.ProcessedFile.FileClassType == FileClassType.File)
            {
                Files.Add(FileString(e.ProcessedFile));
                OrderLog_1.Add(FileString(e.ProcessedFile));
            }
        }

        void OnCommandCompleted(object sender, RoboCommandCompletedEventArgs e)
        {
            Dispatcher.BeginInvoke((Action)(() =>
            {
                ProgressGrid.IsEnabled = false;
                var results = e.Results;
                Console.WriteLine("Files copied: " + results.FilesStatistic.Copied);
                Console.WriteLine("Directories copied: " + results.DirectoriesStatistic.Copied);
            }));

            Command.OnProgressEstimatorCreated -= OnProgressEstimatorCreated;
            Command.OnCopyProgressChanged -= OnCopyProgressChanged;
            Command.OnFileProcessed -= OnFileProcessed;
            Command.OnCommandCompleted -= OnCommandCompleted;

            try
            {
                DirectoryInfo source = new DirectoryInfo(Command.CopyOptions.Source);
                string path = System.IO.Path.Combine(source.Parent.FullName, "EventLogs") + "\\";
                var PathDir = Directory.CreateDirectory(path);
                
                Dirs.Add(""); Dirs.Add(""); Dirs.AddRange(Files);
                File.AppendAllLines($"{path}{Command.Name}_OnFileProcessed.txt", Dirs);

                Dirs2.Add(""); Dirs2.Add(""); Dirs2.AddRange(Files2);
                File.AppendAllLines($"{path}{Command.Name}_CopyProgressChanged.txt", Dirs2);

                File.AppendAllLines($"{path}{Command.Name}_OnFileProcessed_InOrder.txt", OrderLog_1);
                File.AppendAllLines($"{path}{Command.Name}_CopyProgressChanged_InOrder.txt", OrderLog_2);
            }
            catch { }
        }
        #endregion
    }
}
